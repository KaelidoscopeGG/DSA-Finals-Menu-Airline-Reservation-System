#ifndef FLIGHT_H
#define FLIGHT_H

#include <string>
#include <iostream>
#include <iomanip>

using namespace std;

class Flight {
public:
    string flightNumber;
    string departureCity;
    string destinationCity;
    string departureTime;
    string arrivalTime;
    string date;
    int availableSeats;
    double price;

    Flight();
    Flight(string fn, string dc, string destc, string dept,
        string arrt, string dt, int seats, double p);
    void displayFlightInfo() const;
};

#endif 
