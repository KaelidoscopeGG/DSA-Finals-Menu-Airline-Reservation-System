#include <iostream>
#include <string>
#include <iomanip>

#include "Flight.h"
#include "FlightManager.h"

using namespace std;

void handleAddAvailableFlights(FlightManager& fm);
void handleViewAvailableFlights(FlightManager& fm);
void handleSearchFlights(FlightManager& fm);
void handleSaveFlightTransactions(FlightManager& fm);

void MainMenu() {
    cout << "\n[Airline Reservation System]\n"
        << "----------------------------\n"
        << "Main Menu (Admin Side)\n"
        << "1. Add Available Flights (Linked List)\n"
        << "2. View Available Flights (Linked List)\n"
        << "3. Search Flights (Linked List)\n"
        << "4. Save Flight Transactions (File handling)\n"
        << "5. Book Flight / Remove Available Flights (Linked List) / Add Reservation (Queue) (Not Implemented)\n"
        << "6. Search Reservation (Queue) (Not Implemented)\n"
        << "7. Cancel Reservation (Queue) (Not Implemented)\n"
        << "8. View Current Tickets (Queue) (Not Implemented)\n"
        << "9. Save Reservation Transactions (File handling) (Not Implemented)\n"
        << "10. Exit\n"
        << "Enter your choice: ";
}

int main() {
    int choice = 0;

    FlightManager flightManager;

    flightManager.loadFlightsFromFile("flights.txt");

    do {
        MainMenu();
        cin >> choice;
        cin.ignore();
        cout << "\n";

        switch (choice) {
        case 1:
            handleAddAvailableFlights(flightManager);
            break;
        case 2:
            handleViewAvailableFlights(flightManager);
            break;
        case 3:
            handleSearchFlights(flightManager);
            break;
        case 4:
            handleSaveFlightTransactions(flightManager);
            break;
        case 5:
             //todo
        case 6:
             //todo
        case 7:
             //todo
        case 8:
             //todo
        case 9:
            cout << "This feature is not implemented in the current admin-side version.\n";
            break;
        case 10:
            cout << "Exiting program, goodbye!\n";
            flightManager.saveFlightsToFile("flights.txt");
            return 0;
        default:
            cout << "Please enter a valid choice (1-10).\n";
        }

        if (choice != 10) {
            cout << "\nPress Enter to continue...";
            cin.ignore();
        }

    } while (true);
}

void handleAddAvailableFlights(FlightManager& fm) {
    cout << "--- Add New Flight ---\n";
    string fn, dc, destc, dept, arrt, dt;
    int seats;
    double price;

    cout << "Enter Flight Number: "; getline(cin, fn);
    cout << "Enter Departure City: "; getline(cin, dc);
    cout << "Enter Destination City: "; getline(cin, destc);
    cout << "Enter Date (YYYY-MM-DD): "; getline(cin, dt);
    cout << "Enter Departure Time (HH:MM): "; getline(cin, dept);
    cout << "Enter Arrival Time (HH:MM): "; getline(cin, arrt);
    cout << "Enter Available Seats: "; cin >> seats;
    cout << "Enter Price: $"; cin >> price;
    cin.ignore();

    Flight newFlight(fn, dc, destc, dept, arrt, dt, seats, price);
    fm.addFlight(newFlight);
}

void handleViewAvailableFlights(FlightManager& fm) {
    fm.viewAllFlights();
}

void handleSearchFlights(FlightManager& fm) {
    cout << "--- Search Flights ---\n";
    string searchFlightNum;
    cout << "Enter Flight Number to search: ";
    getline(cin, searchFlightNum);

    Flight* foundFlight = fm.searchFlight(searchFlightNum);
    if (foundFlight != nullptr) {
        cout << "Flight found:\n";
        foundFlight->displayFlightInfo();
    }
    else {
        cout << "Flight " << searchFlightNum << " not found.\n";
    }
}

void handleSaveFlightTransactions(FlightManager& fm) {
    fm.saveFlightsToFile("flights.txt");
}
